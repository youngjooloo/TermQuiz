package com.termquiz.team.vo;

import lombok.Data;

@Data
public class MovieQuizVO {
	private int movieqNo;
	private String movieqAnswer;
	private String movieqHint1;
	private String movieqHint2;
	private String movieqHint3;
	private String movieqHint4;
	private String movieqHint5;
//movie quiz	
	private String movieqId;
	private int score;
//movie quiz score

}
